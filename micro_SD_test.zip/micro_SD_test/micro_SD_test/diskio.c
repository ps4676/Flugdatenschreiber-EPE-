/*-----------------------------------------------------------------------*/
/* Low level disk I/O module SKELETON for FatFs     (C)ChaN, 2019        */
/*-----------------------------------------------------------------------*/
/* If a working storage control module is available, it should be        */
/* attached to the FatFs via a glue function rather than modifying it.   */
/* This is an example of glue functions to attach various exsisting      */
/* storage control modules to the FatFs module with a defined API.       */
/*-----------------------------------------------------------------------*/

#include "ff.h"			/* Obtains integer types */
#include "diskio.h"		/* Declarations of disk functions */

/* Definitions of physical drive number for each drive */
#define DEV_RAM		0	/* Example: Map Ramdisk to physical drive 0 */
#define DEV_MMC		1	/* Example: Map MMC/SD card to physical drive 1 */
#define DEV_USB		2	/* Example: Map USB MSD to physical drive 2 */
#include "diskio.h"
#include <avr/io.h>
#include <util/delay.h>

#define SD_CS_LOW()  PORTB &= ~(1 << PB2)
#define SD_CS_HIGH() PORTB |= (1 << PB2)

// Initialize disk drive
DSTATUS disk_initialize(BYTE pdrv) {
	SD_CS_HIGH();  // Deselect SD card
	_delay_ms(10);

	// Send 80 clock pulses for SD initialization
	for (uint8_t i = 0; i < 10; i++) {
		SPI_MasterTransmit(0xFF);
	}
	
	SD_CS_LOW();  // Select SD card
	// Send CMD0 to reset SD card, receive response
	SPI_MasterTransmit(0x40);  // CMD0
	SPI_MasterTransmit(0x00);  // Argument
	SPI_MasterTransmit(0x00);
	SPI_MasterTransmit(0x00);
	SPI_MasterTransmit(0x00);
	SPI_MasterTransmit(0x95);  // CRC valid for CMD0

	char response;
	do {
		response = SPI_MasterReceive();
	} while (response != 0x01);  // Wait for CMD0 response
	
	return (response == 0x01) ? 0 : STA_NOINIT;  // Return 0 if successful, STA_NOINIT if failed
}

// Read sector
DRESULT disk_read(BYTE pdrv, BYTE* buff, DWORD sector, UINT count) {
	// Implement your sector read logic using SPI communication with the SD card
	// Use SPI to read data from the SD card, similar to how you would with Petit FatFs
	return RES_OK;
}

// Write sector
DRESULT disk_write(BYTE pdrv, const BYTE* buff, DWORD sector, UINT count) {
	// Implement your sector write logic using SPI communication with the SD card
	return RES_OK;
}

// Disk status (can be simple if only one drive)
DSTATUS disk_status(BYTE pdrv) {
	return 0;
}


/*-----------------------------------------------------------------------*/
/* Get Drive Status                                                      */
/*-----------------------------------------------------------------------*/




/*-----------------------------------------------------------------------*/
/* Read Sector(s)                                                        */
/*-----------------------------------------------------------------------*/




/*-----------------------------------------------------------------------*/
/* Write Sector(s)                                                       */
/*-----------------------------------------------------------------------*/






/*-----------------------------------------------------------------------*/
/* Miscellaneous Functions                                               */
/*-----------------------------------------------------------------------*/

DRESULT disk_ioctl (
	BYTE pdrv,		/* Physical drive nmuber (0..) */
	BYTE cmd,		/* Control code */
	void *buff		/* Buffer to send/receive control data */
)
{
	DRESULT res;
	int result;

	switch (pdrv) {
	case DEV_RAM :

		// Process of the command for the RAM drive

		return res;

	case DEV_MMC :

		// Process of the command for the MMC/SD card

		return res;

	case DEV_USB :

		// Process of the command the USB drive

		return res;
	}

	return RES_PARERR;
}

