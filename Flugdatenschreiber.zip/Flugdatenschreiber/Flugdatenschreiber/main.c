#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <string.h>
#include <avr/sleep.h>
#include <stdio.h>
#include "fat.h"
#include "partition.h"
#include "sd_raw.h"
#include "oled_ssd1306.h"
#include "sd_raw.h"

#define DEBUG 1
#define ADC_CHANNEL 7   // ADC7 is connected to PC7
#define BUTTON_PIN PC1   // Button is connected to PC1

volatile uint8_t logging_enabled = 0;  // Flag to indicate if logging is enabled

void clock_init(void) {
	// Disable the Clock Prescaler by setting it to 1
	CLKPR = (1 << CLKPCE);   // Enable change of the Clock Prescaler
	CLKPR = 0x00;            // Set prescaler to 1, resulting in 16 MHz clock (assuming external 16 MHz crystal)
}

void adc_init(void) {
	// Set the reference voltage to AVcc and select the ADC7 channel
	ADMUX = (1 << REFS0) | ADC_CHANNEL;  // AVcc as reference, select ADC7 (PC7)
	
	// Enable the ADC and set the prescaler to 128 for a 125 kHz ADC clock (16 MHz / 128)
	ADCSRA = (1 << ADEN) | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);
}

uint16_t adc_read(void) {
	// Start the conversion
	ADCSRA |= (1 << ADSC);

	// Wait for the conversion to complete
	while (ADCSRA & (1 << ADSC));

	// Return the ADC result
	return ADC;
}

void timer1_init(void) {
	// Configure Timer1 in CTC mode
	TCCR1B |= (1 << WGM12); // CTC mode
	// Set the prescaler to 256 for a timer tick of 1/62500 seconds (16 MHz / 256)
	TCCR1B |= (1 << CS12);
	// Calculate the compare value for 0.5-second delay
	OCR1A = 31249; // 0.5s = (OCR1A+1) * 256 / 16 MHz
	// Enable Timer1 Compare A Match Interrupt
	TIMSK1 |= (1 << OCIE1A);
	// Enable global interrupts
	sei();
}

volatile uint8_t timer_flag = 0;

ISR(TIMER1_COMPA_vect) {
	// Set flag to indicate that the timer interval has elapsed
	timer_flag = 1;
}

void button_init(void) {
	// Set PC1 as input with pull-up resistor
	DDRC &= ~(1 << BUTTON_PIN);  // Configure PC1 as input
	PORTC |= (1 << BUTTON_PIN);  // Enable pull-up resistor on PC1
}

uint8_t debounce_button(void) {
	// Simple debounce routine
	if (!(PINC & (1 << BUTTON_PIN))) {  // If button is pressed (logic low)
		_delay_ms(50);  // Wait 50ms for debounce
		if (!(PINC & (1 << BUTTON_PIN))) {  // Check again if button is still pressed
			return 1;
		}
	}
	return 0;
}

void setup(void) {
	clock_init();
	adc_init();
	oled_init();
	oled_clear_screen();
	oled_gotoxy(0,0);
	timer1_init();  // Initialize the timer for 0.5s intervals
	button_init();  // Initialize the button on PC1
}

int main() {
	set_sleep_mode(SLEEP_MODE_IDLE);
	setup();

	// Initialize SD card
	if (!sd_raw_init()) {
		#if DEBUG
		oled_write("SD init failed");
		#endif
		return 1;
	}

	// Open partition
	struct partition_struct* partition = partition_open(sd_raw_read, sd_raw_read_interval,
	#if SD_RAW_WRITE_SUPPORT
	sd_raw_write, sd_raw_write_interval,
	#else
	0, 0,
	#endif
	0);
	if (!partition) {
		#if DEBUG
		oled_write("Partition open failed");
		#endif
		return 1;
	}

	// Open filesystem
	struct fat_fs_struct* fs = fat_open(partition);
	if (!fs) {
		#if DEBUG
		oled_write("Filesystem open failed");
		#endif
		return 1;
	}

	// Open root directory
	struct fat_dir_entry_struct directory;
	fat_get_dir_entry_of_path(fs, "/", &directory);
	struct fat_dir_struct* dd = fat_open_dir(fs, &directory);
	if (!dd) {
		#if DEBUG
		oled_write("Root directory open failed");
		#endif
		return 1;
	}

	struct fat_file_struct* fd = NULL;  // File descriptor, initially NULL

	while (1) {
		// Check button press to toggle logging
		if (debounce_button()) {
			logging_enabled = !logging_enabled;  // Toggle logging state
			oled_clear_screen();
			oled_gotoxy(0,0);
			if (logging_enabled) {
				oled_write("Logging started");

				// Open or create CSV file
				struct fat_dir_entry_struct file_entry;
				if (fat_create_file(dd, "data.txt", &file_entry)) {
					fd = fat_open_file(fs, &file_entry);
					if (!fd) {
						oled_write("Error opening file");
						logging_enabled = 0;  // Stop logging if file can't be opened
					}
					} else {
					oled_write("File creation failed");
					logging_enabled = 0;  // Stop logging if file creation failed
				}

				} else {
				oled_write("Logging stopped");
				
				// Close the file when logging stops
				if (fd) {
					fat_close_file(fd);
					fd = NULL;
				}
			}
			_delay_ms(50);  // Prevent bouncing issues
		}

if (logging_enabled && timer_flag) {  // Check if logging is enabled and 0.5s elapsed
	timer_flag = 0;  // Reset flag

	// Read ADC value
	uint16_t adc_value = adc_read();

	// Convert ADC value to a string
	char adc_str[16];
	snprintf(adc_str, sizeof(adc_str), "%u,", adc_value);  // Convert ADC value to a string

	// Seek to the end of the file before appending
	int32_t offset = -1;
	fat_seek_file(fd, &offset, FAT_SEEK_END);

	// Write the string representation of the ADC value to the file
	int bytes_written = fat_write_file(fd, (uint8_t*)adc_str, strlen(adc_str));
	if (bytes_written < 0) {
		oled_write("Write failed");
		} else {
		#if DEBUG
		oled_write("ADC written ");
		#endif
	}
}




	}
	fat_close_dir(dd);
	fat_close(fs);
	partition_close(partition);

	return 0;
}
