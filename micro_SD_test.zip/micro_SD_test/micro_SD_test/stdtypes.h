typedef signed char si8;
typedef unsigned char u8;
typedef signed int si16;
typedef unsigned int u16;
typedef signed long  si32;
typedef unsigned long u32;
typedef signed long long si64;
typedef unsigned long long u64;
